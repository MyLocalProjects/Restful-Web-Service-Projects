package com.behl.app.ws.restassuredtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileAppWsRestAssuredTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileAppWsRestAssuredTestApplication.class, args);
	}

}
