package com.behl.app.ws.ui.model.response;

public enum RequestOperationName {

	DELETE, VERIFY_EMAIL, REQUEST_PASSWORD_RESET, PASSWORD_RESET;
}
