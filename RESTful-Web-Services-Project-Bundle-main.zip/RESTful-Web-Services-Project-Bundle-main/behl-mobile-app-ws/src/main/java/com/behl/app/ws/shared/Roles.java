package com.behl.app.ws.shared;

public enum Roles {

	ROLE_USER, ROLE_ADMIN
}
