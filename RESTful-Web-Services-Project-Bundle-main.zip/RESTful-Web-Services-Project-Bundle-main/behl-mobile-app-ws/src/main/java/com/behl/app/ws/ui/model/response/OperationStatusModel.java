package com.behl.app.ws.ui.model.response;

public class OperationStatusModel {

	private String operationName;
	private String operationResult;


	public String getOperationResult() {
		return operationResult;
	}

	public void setOperationResult(String operationResult) {
		this.operationResult = operationResult;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

}
